-------------------------------------------------


    ____                 __  ____  _ ___ __       
   / __ \__  ______     / / / / /_(_) (_) /___  __
  / /_/ / / / / __ \   / / / / __/ / / / __/ / / /
 / _, _/ /_/ / / / /  / /_/ / /_/ / / / /_/ /_/ / 
/_/ |_|\__,_/_/ /_/   \____/\__/_/_/_/\__/\__, /  
                                         /____/

					v2.1.0
-------------------------------------------------

Made by Julian H.

Copyright © BitBros Studios 2021. All rights reserved.

==========
This app is free and always will be. If you paid for this and/or got it from anywhere other
than https://home.jeweledfox.repl.co, uninstall this immediately and report the site you got it from.
==========

Thank you for using Run Utility! This is a quick documentation on how it works.

Run was coded in Visual Basic. As such, you need Windows Based Script Host or an equivalent to use it. It's prebuilt into most Windows devices.

-----
Usage
-----

It's easy to use Run. Just input a path to anywhere in your computer, and Run should open it. Run can't open a path that doesn't exist.

Run can open files too - just input the path to the file. Just make sure that running files is on in Settings.

You can even run Command Prompt commands. Just enter "cmd" and then your command. Make sure that running commands are on in Settings.

Example: cmd /k echo Hello World!

-----
Input Parameters
-----

The path you input:

	- Cannot have quotes around it.
	- Has to use backslashes (\), not slashes (/).
	- Has to be a full path, including the drive.
	- Cannot have two backslashes after the drive.

Example: C:\Users\Me\Documents\

-----
Settings
-----

You can configure multiple advanced settings for Run, through the Settings app.

It's not like most settings apps, instead of a list that can be changed, Run Settings will prompt the user with a series of inputs.

Once the user has finished responding to the inputs, they will be prompted to save the changes.

-----
Troubleshooting
-----

You may run into an unexpected error while using the app. This will guide you through fixing them.

Common errors:
	- "Something went wrong with applying settings. The file may be corrupted, try running Settings again."
		This means that there was an error while the app was applying settings set through the Settings app. Another thing that can happen 
		with this is when the app runs, but settings don't seem to be working as the user set them.

		This problem can usually be fixed by running Settings again, once or twice.
	
	- "Something went wrong when applying settings. Please try again."
		This error occurs when applying settings. Try running Settings again. If that doesn't work, make sure that the config.txt file in the 
		assets folder isn't missing.
	
	- "No application is associated with the specified file for this operation."
		This error occurs when a file is opened, but there's no app set to open that file type. To fix this, try going to the file's path
		in the file explorer and setting a opening method.



___________________

Thanks for reading! If you have any questions, comments, or problems, contact Julian at https://home.jeweledfox.repl.co via the Contact link.
